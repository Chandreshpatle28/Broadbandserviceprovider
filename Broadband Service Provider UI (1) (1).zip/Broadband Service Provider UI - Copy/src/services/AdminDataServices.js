const baseURL = "https://localhost:44339";
const axios = require("axios").default;

export const AdminDataServices = {
  UpdateAdminAddress,
  GetAdminAddress,
  AddProduct,
  UpdateProduct,
  GetAllProduct,
  DeleteProduct,
  GetFeedback,
  GetTechnicianList,
  UpdateTicket,
  GetTicketHistory,
  DeleteFeedback,
};

function UpdateAdminAddress(reqbody) {
  // debugger;
  const requestOptions = {
    method: "PATCH",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
    body: JSON.stringify(reqbody),
  };
  return fetch(baseURL + `/api/Admin/UpdateAdminAddress`, requestOptions)
    .then((res) => res.json())
    .then((result) => {
      return result;
    });
}

function GetAdminAddress() {
  const requestOptions = {
    method: "GET",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
  };
  return fetch(
    baseURL +
      `/api/Admin/GetAdminAddress?UserID=${localStorage.getItem("AdminID")}`,
    requestOptions
  )
    .then((res) => res.json())
    .then((result) => {
      return result;
    });
}

async function AddProduct(reqbody) {
  // debugger;
  const headers = {
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
  };

  await axios
    .post(baseURL + "/api/Admin/AddProduct", reqbody, true && headers)
    .then((result) => {
      console.log("Result : ", result);
      return result;
    });
}

async function UpdateProduct(reqbody) {
  // debugger;
  const headers = {
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
  };

  await axios
    .patch(baseURL + "/api/Admin/UpdateProduct", reqbody, true && headers)
    .then((result) => {
      console.log("Result : ", result);
      return result;
    });
}

function GetAllProduct(reqbody) {
  // debugger;
  const requestOptions = {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
    body: JSON.stringify(reqbody),
  };
  return fetch(baseURL + `/api/Admin/GetAllProduct`, requestOptions)
    .then((res) => res.json())
    .then((result) => {
      return result;
    });
}

function DeleteProduct(reqbody) {
  // debugger;
  const requestOptions = {
    method: "DELETE",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
    body: JSON.stringify(reqbody),
  };
  return fetch(baseURL + `/api/Admin/DeleteProduct`, requestOptions)
    .then((res) => res.json())
    .then((result) => {
      return result;
    });
}

function GetFeedback(reqbody) {
  // debugger;
  const requestOptions = {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
    body: JSON.stringify(reqbody),
  };
  return fetch(baseURL + `/api/Feedback/GetFeedback`, requestOptions)
    .then((res) => res.json())
    .then((result) => {
      return result;
    });
}

function DeleteFeedback(reqbody) {

  const requestOptions = {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
    body: JSON.stringify(reqbody),
  };
  return fetch(baseURL + `/api/Feedback/DeleteFeedback`, requestOptions)
    .then((res) => res.json())
    .then((result) => {
      return result;
    });

  // const headers = {
  //   headers: {
  //     "content-type": "application/json",
  //     "cache-control": "no-cache",
  //     Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
  //   },
  // };

  // axios
  //   .post(baseURL + "/api/Feedback/DeleteFeedback", reqbody, true && headers)
  //   .then((result) => {
  //     console.log("Result : ", result);
  //     return result;
  //   });
}

function GetTechnicianList(reqbody) {
  // debugger;
  const requestOptions = {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
    body: JSON.stringify(reqbody),
  };
  return fetch(baseURL + `/api/admin/GetTechnicianList`, requestOptions)
    .then((res) => res.json())
    .then((result) => {
      return result;
    });
}

//
function UpdateTicket(reqbody) {
  // debugger;
  const requestOptions = {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
    body: JSON.stringify(reqbody),
  };
  return fetch(baseURL + `/api/admin/UpdateTicket`, requestOptions)
    .then((res) => res.json())
    .then((result) => {
      return result;
    });
}

function GetTicketHistory(reqbody) {
  const requestOptions = {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Authorization: `Bearer ${localStorage.getItem("AdminToken")}`,
    },
    body: JSON.stringify(reqbody),
  };
  return fetch(baseURL + `/api/Customer/GetTicketHistory`, requestOptions)
    .then((res) => res.json())
    .then((result) => {
      return result;
    });
}
