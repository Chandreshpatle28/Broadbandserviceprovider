import React, { Component } from "react";
import "./History.scss";
import { CustomerDataServices } from "../../services/CustomerDataServices";
import { AdminDataServices } from "../../services/AdminDataServices";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Pagination from "@material-ui/lab/Pagination";
import IconButton from "@material-ui/core/IconButton";
import TextField from "@material-ui/core/TextField";
import DeleteIcon from "@material-ui/icons/Delete";
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";
import Snackbar from "@material-ui/core/Snackbar";
import CloseIcon from "@material-ui/icons/Close";
import Button from "@material-ui/core/Button";
import Modal from "@material-ui/core/Modal";
import Fade from "@material-ui/core/Fade";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";

export default class History extends Component {
  constructor() {
    super();
    this.state = {
      rows: [],
      //
      TicketID: 0,
      UserID: localStorage.getItem("CustomerID"),
      City: "",
      Reportor: "",
      Assigner: "",
      PlanType: "",
      RaiseType: "",
      Summary: "",
      Description: "",
      Status: "",
      //
      PageNumber: 1,
      TotalPage: 0,
      //
      Message: "",
      OpenSnackBar: false,
      OpenLoader: false,
      OpenTicket: false,
    };
  }

  componentWillMount() {
    console.log("History component will mount calling ... ");
    this.GetTicketHistory(this.state.PageNumber);
  }

  GetTicketHistory = (CurrentPageNumber) => {
    let data = {
      userID: localStorage.getItem("CustomerID"),
      pageNumber: CurrentPageNumber,
      numberOfRecordPerPage: 10,
    };
    CustomerDataServices.GetTicketHistory(data)
      .then((data) => {
        console.log("GetTicketHistory Data : ", data);
        this.setState({
          rows: data.data,
          TotalPage: data.totalPage,
        });
      })
      .catch((error) => {
        console.log("GetTicketHistory Error : ", error);
        this.setState({ Message: "Something Went Wrong", OpenSnackBar: true });
      });
  };

  handleDeleteTicket = (TicketID) => {
    let data = {
      ticketID: TicketID,
    };
    CustomerDataServices.DeleteTicketHistory(data)
      .then((data) => {
        console.log("DeleteTicketHistory Data : ", data);
        this.setState({ Message: data.message, OpenSnackBar: true });
        this.GetTicketHistory(this.state.PageNumber);
      })
      .catch((error) => {
        console.log("DeleteTicketHistory Error : ", error);
        this.setState({ Message: "Something Went Wrong", OpenSnackBar: true });
        this.GetTicketHistory(this.state.PageNumber);
      });
  };

  handlePaging = async (e, value) => {
    console.log("Current Page : ", value);
    this.GetTicketHistory(value);
  };

  handleOpenTicket = (data) => {
    this.setState({
      TicketID: data.ticketID,
      City: data.city,
      Reportor: data.reportor,
      Assigner: data.assigner,
      PlanType: data.planType,
      RaiseType: data.raiseType,
      Summary: data.summary,
      Description: data.description,
      Status: data.status,
      OpenTicket: true,
    });
  };

  handleChanges = (e) => {
    const { name, value } = e.target;
    this.setState(
      { [name]: value },
      console.log("name : ", name, "Value : ", value)
    );
  };

  handleClose = () => {
    console.log("Handle Close Calling ...");
    this.setState({
      OpenTicket: false,
    });
  };

  handleEditTicket = () => {
    let state = this.state;

    let data = {
      ticketID: state.TicketID,
      userID: state.UserID,
      city: state.City !== "NA" ? localStorage.getItem("Customer_City") : "NA",
      assigner: state.Assigner,
      reportor: state.Reportor,
      planType: state.PlanType,
      raiseType: state.RaiseType,
      summary: state.Summary,
      description: state.Description,
      status: state.Status,
    };

    AdminDataServices.UpdateTicket(data)
      .then((data) => {
        console.log("UpdateTicket Data : ", data);
        this.setState({
          OpenTicket: false,
          OpenSnackBar: true,
          Message: data.message,
        });
        this.GetTicketHistory(this.state.PageNumber);
      })
      .catch((error) => {
        console.log("UpdateTicket Error : ", error);
        this.setState({
          OpenTicket: false,
          OpenSnackBar: true,
          Message: "Something went wrong",
        });
        this.GetTicketHistory(this.state.PageNumber);
      });
  };

  render() {
    let state = this.state;
    let self = this;
    return (
      <div className="History-MainContainer">
        <div className="History-MainContainer-Header">Ticket History</div>
        <div className="History-MainContainer-Body">
          <TableContainer component={Paper}>
            <Table aria-label="simple table">
              <TableHead>
                <TableRow style={{ display: "flex" }}>
                  <TableCell style={{ fontSize: 16, flex: 0.2 }} align="left">
                    Id
                  </TableCell>
                  <TableCell style={{ fontSize: 16, flex: 5 }} align="left">
                    Summary
                  </TableCell>
                  <TableCell style={{ fontSize: 16, flex: 1 }} align="center">
                    Product Type&nbsp;
                  </TableCell>
                  <TableCell style={{ fontSize: 16, flex: 1 }} align="center">
                    Assigner&nbsp;
                  </TableCell>
                  <TableCell style={{ fontSize: 16, flex: 1 }} align="center">
                    Reporter&nbsp;
                  </TableCell>
                  <TableCell style={{ fontSize: 16, flex: 1 }} align="center">
                    Status&nbsp;
                  </TableCell>
                  <TableCell style={{ fontSize: 16, flex: 1 }} align="center">
                    Operation
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {state.rows !== null
                  ? state.rows.map((row) => (
                      <TableRow key={row.name} style={{ display: "flex" }}>
                        <TableCell
                          align="left"
                          component="th"
                          scope="row"
                          style={{ flex: 0.2 }}
                          onClick={() => {
                            this.handleOpenTicket(row);
                          }}
                        >
                          {row.ticketID}
                        </TableCell>
                        <TableCell
                          align="left"
                          style={{ flex: 5 }}
                          onClick={() => {
                            this.handleOpenTicket(row);
                          }}
                        >
                          {row.summary}
                        </TableCell>
                        <TableCell
                          align="center"
                          style={{ flex: 1 }}
                          onClick={() => {
                            this.handleOpenTicket(row);
                          }}
                        >
                          {row.planType}
                        </TableCell>
                        <TableCell
                          align="center"
                          style={{ flex: 1 }}
                          onClick={() => {
                            this.handleOpenTicket(row);
                          }}
                        >
                          {row.assigner}
                        </TableCell>
                        <TableCell
                          align="center"
                          style={{ flex: 1 }}
                          onClick={() => {
                            this.handleOpenTicket(row);
                          }}
                        >
                          {row.reportor}
                        </TableCell>
                        <TableCell
                          align="center"
                          style={{ flex: 1 }}
                          onClick={() => {
                            this.handleOpenTicket(row);
                          }}
                        >
                          {row.status}
                        </TableCell>
                        <TableCell
                          align="center"
                          style={{ flex: 1, padding: 0 }}
                        >
                          {/* <IconButton
                            variant="outlined"
                            color="primary"
                            size="medium"
                            onClick={() => {
                              self.handleEditTicket(row);
                            }}
                            // style={{ margin: '0 px 0 0' }}
                          >
                            <EditIcon size="medium" />
                          </IconButton> */}
                          <IconButton
                            variant="outlined"
                            style={{ color: "black" }}
                            size="medium"
                            onClick={() => {
                              self.handleDeleteTicket(row.ticketID);
                            }}
                          >
                            <DeleteIcon size="medium" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))
                  : null}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
        <div className="History-MainContainer-Footer">
          <Pagination
            count={this.state.TotalPage}
            Page={this.state.PageNumber}
            onChange={this.handlePaging}
            variant="outlined"
            shape="rounded"
            color="secondary"
          />
        </div>

        <Modal
          open={this.state.OpenTicket}
          onClose={this.handleClose}
          closeAfterTransition
          BackdropComponent={Backdrop}
          BackdropProps={{
            timeout: 500,
          }}
          className="Model-Create-Ticket"
        >
          <Fade in={this.state.OpenTicket}>
            <div className="Model-Create-Ticket-Main">
              <div className="Model-Create-Ticket-Header">
                <div className="Model-Create-Ticket-Header-Text">
                  Update Ticket
                </div>
              </div>
              <div className="Model-Create-Ticket-Body">
                <InputLabel required>Plan Type</InputLabel>
                <FormControl
                  variant="filled"
                  className="Model-Create-Ticket-Body-PlanType"
                  size="small"
                  name="PlanType"
                  style={{ margin: "5px 0 20px 0" }}
                >
                  <Select
                    native
                    name="PlanType"
                    value={state.PlanType}
                    onChange={this.handleChanges}
                  >
                    <option value="device">Device</option>
                    <option value="plan">Plans</option>
                    <option value="other">Other</option>
                  </Select>
                </FormControl>
                <InputLabel required>Raise Type</InputLabel>
                <FormControl
                  variant="filled"
                  size="small"
                  name="RaiseType"
                  className="Model-Create-Ticket-Body-IssueType"
                  style={{ margin: "5px 0 20px 0" }}
                >
                  <Select
                    native
                    name="RaiseType"
                    value={state.RaiseType}
                    onChange={this.handleChanges}
                  >
                    <option value="issue">Issue</option>
                    <option value="improvement">Improvement</option>
                    <option value="changerequest">Change Request</option>
                  </Select>
                </FormControl>
                <div className="Line"></div>
                <InputLabel required>Summary</InputLabel>
                <TextField
                  variant="outlined"
                  size="small"
                  name="Summary"
                  className="Model-Create-Ticket-Body-Summary"
                  style={{ margin: "5px 0 20px 0" }}
                  error={state.SummaryFlag}
                  value={state.Summary}
                  onChange={this.handleChanges}
                />
                <InputLabel required>Description</InputLabel>
                <TextField
                  variant="outlined"
                  size="small"
                  name="Description"
                  className="Model-Create-Ticket-Body-Summary"
                  style={{ margin: "5px 0 0 0" }}
                  multiline
                  rows={5}
                  error={state.DescriptionFlag}
                  value={state.Description}
                  onChange={this.handleChanges}
                />
              </div>
              <div className="Model-Create-Ticket-Footer">
                <Button
                  variant="contained"
                  style={{ margin: "10px" }}
                  onClick={() => {
                    this.handleClose();
                  }}
                >
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => {
                    this.handleEditTicket();
                  }}
                >
                  Edit
                </Button>
              </div>
            </div>
          </Fade>
        </Modal>

        <Backdrop
          style={{ zIndex: "1", color: "#fff" }}
          open={this.state.OpenLoader}
          onClick={() => {
            this.setState({ OpenLoader: false });
          }}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
        <Snackbar
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
          open={state.OpenSnackBar}
          autoHideDuration={2000}
          onClose={this.handleSnackBarClose}
          message={state.Message}
          action={
            <React.Fragment>
              <Button
                color="secondary"
                size="small"
                onClick={this.handleSnackBarClose}
              >
                UNDO
              </Button>
              <IconButton
                size="small"
                aria-label="close"
                color="inherit"
                onClick={this.handleSnackBarClose}
              >
                <CloseIcon fontSize="small" />
              </IconButton>
            </React.Fragment>
          }
        />
      </div>
    );
  }
}
