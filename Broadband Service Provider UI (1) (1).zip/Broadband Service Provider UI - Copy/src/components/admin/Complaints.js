import React, { Component } from "react";
import "./Complaints.scss";
import { AdminDataServices } from "../../services/AdminDataServices";
import { CustomerDataServices } from "../../services/CustomerDataServices";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Pagination from "@material-ui/lab/Pagination";
import IconButton from "@material-ui/core/IconButton";
import EditIcon from "@material-ui/icons/Edit";
import DeleteIcon from "@material-ui/icons/Delete";
import Modal from "@material-ui/core/Modal";
import Backdrop from "@material-ui/core/Backdrop";
import Fade from "@material-ui/core/Fade";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import CircularProgress from "@material-ui/core/CircularProgress";
import Snackbar from "@material-ui/core/Snackbar";
import CloseIcon from "@material-ui/icons/Close";

export default class Complaints extends Component {
  constructor() {
    super();
    this.state = {
      rows: [],
      TechnicianData: [],
      StatusList: ["done", "inprogress", "pending"],
      //
      PageNumber: 1,
      TotalPage: 0,
      //
      TicketID: "",
      InsertionDate: "",
      UserID: 0,
      Summary: "",
      PlanType: "",
      RaiseType: "",
      Assigner: "",
      Reportor: "",
      Status: "",
      Description: "",
      City: "",
      //
      Message: "",
      //
      OpenTicket: false,
      OpenLoader: false,
      OpenSnackBar: false,
    };
  }

  componentWillMount() {
    console.log("Complaints component will mount calling ... ");
    this.GetTicketHistory(this.state.PageNumber);
  }

  GetTechnicianList = async (City) => {
    let data = {
      city: City,
    };
    await AdminDataServices.GetTechnicianList(data)
      .then((data) => {
        console.log("GetTechnicianList Data : ", data);
        this.setState({
          TechnicianData: data.data,
        });
      })
      .catch((error) => {
        console.log("GetTechnicianList Error : ", error);
      });
  };

  GetTicketHistory = (CurrentPageNumber) => {
    let data = {
      userID: -1,
      pageNumber: CurrentPageNumber,
      numberOfRecordPerPage: 10,
    };
    AdminDataServices.GetTicketHistory(data)
      .then((data) => {
        console.log("GetTicketHistory Data : ", data);
        this.setState({
          rows: data.data,
          TotalPage: data.totalPage,
        });
      })
      .catch((error) => {
        console.log("GetTicketHistory Error : ", error);
      });
  };

  handleUpdateTicket = () => {
    let data = {
      ticketID: this.state.TicketID,
      userID: this.state.UserID,
      city: this.state.City,
      assigner: this.state.Assigner,
      reportor: this.state.Reportor,
      planType: this.state.PlanType,
      raiseType: this.state.RaiseType,
      summary: this.state.Summary,
      description: this.state.Description,
      status: this.state.Status,
    };

    AdminDataServices.UpdateTicket(data)
      .then((data) => {
        console.log("UpdateTicket Data : ", data);
        this.setState({
          OpenTicket: false,
          OpenSnackBar: true,
          Message: data.message,
        });
        this.GetTicketHistory(this.state.PageNumber);
      })
      .catch((error) => {
        console.log("UpdateTicket Error : ", error);
        this.setState({
          OpenTicket: false,
          OpenSnackBar: true,
          Message: "Something went wrong",
        });
        this.GetTicketHistory(this.state.PageNumber);
      });
  };

  handleDeleteTicket = (TicketID) => {
    let data = {
      ticketID: TicketID,
    };
    CustomerDataServices.DeleteTicketHistory(data)
      .then((data) => {
        console.log("DeleteTicketHistory Data : ", data);
        this.setState({ Message: data.message, OpenSnackBar: true });
        this.GetTicketHistory(this.state.PageNumber);
      })
      .catch((error) => {
        console.log("DeleteTicketHistory Error : ", error);
        this.setState({ Message: "Something Went Wrong", OpenSnackBar: true });
        this.GetTicketHistory(this.state.PageNumber);
      });
  };

  handleChanges = (e) => {
    const { name, value } = e.target;
    this.setState(
      { [name]: value },
      console.log("name : ", name, "Value : ", value)
    );
  };

  handleClose = () => {
    console.log("Handle Close Calling ...");
    this.setState({
      OpenTicket: false,
    });
  };

  OpenTicketModel = async (data) => {
    await this.GetTechnicianList(data.city);
    await this.setState({
      OpenTicket: true,
      TicketID: data.ticketID,
      InsertionDate: data.insertionDate,
      UserID: data.userID,
      Summary: data.summary,
      RaiseType: data.raiseType,
      PlanType: data.planType,
      Assigner: data.assigner,
      Reportor: data.reportor,
      Status: data.status,
      Description: data.description,
      City: data.city,
    });
  };

  render() {
    let state = this.state;
    let self = this;
    console.log("Complaints State : ", state);
    return (
      <div className="Complaints-MainContainer">
        <div className="Complaints-MainSubContainer">
          <div className="Complaints-MainSubContainer-Header">
            Complaints List
          </div>
          <div className="Complaints-MainSubContainer-Body">
            <TableContainer component={Paper}>
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow style={{ display: "flex" }}>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 0.2,
                      }}
                      align="left"
                    >
                      Id
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 5,
                      }}
                      align="left"
                    >
                      Summary
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 1.2,
                      }}
                      align="left"
                    >
                      Product Type
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 1,
                      }}
                      align="left"
                    >
                      Assigner&nbsp;
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 1,
                      }}
                      align="left"
                    >
                      Reporter&nbsp;
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 1,
                      }}
                      align="left"
                    >
                      Status&nbsp;
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 1,
                      }}
                      align="left"
                    >
                      Operation
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {state.rows.map((row) => (
                    <TableRow key={row.name} style={{ display: "flex" }}>
                      <TableCell
                        align="left"
                        component="th"
                        scope="row"
                        style={{ flex: 0.2 }}
                        onClick={() => {
                          this.OpenTicketModel(row);
                        }}
                      >
                        {row.ticketID}
                      </TableCell>
                      <TableCell
                        align="left"
                        style={{ flex: 4.7 }}
                        onClick={() => {
                          this.OpenTicketModel(row);
                        }}
                      >
                        {row.summary}
                      </TableCell>
                      <TableCell
                        align="left"
                        style={{ flex: 1.1 }}
                        onClick={() => {
                          this.OpenTicketModel(row);
                        }}
                      >
                        {row.planType}
                      </TableCell>
                      <TableCell
                        align="left"
                        style={{ flex: 0.9 }}
                        onClick={() => {
                          this.OpenTicketModel(row);
                        }}
                      >
                        {row.assigner}
                      </TableCell>
                      <TableCell
                        align="left"
                        style={{ flex: 1 }}
                        onClick={() => {
                          this.OpenTicketModel(row);
                        }}
                      >
                        {row.reportor}
                      </TableCell>
                      <TableCell
                        align="left"
                        style={{ flex: 1 }}
                        onClick={() => {
                          this.OpenTicketModel(row);
                        }}
                      >
                        {row.status}
                      </TableCell>
                      <TableCell
                        align="left"
                        style={{
                          flex: 1.2,
                          padding: 0,
                        }}
                      >
                        {/* <IconButton
                          variant="outlined"
                          color="primary"
                          size="medium"
                          onClick={() => {
                            self.handleEditTicket(row);
                          }}
                          // style={{ margin: '0 px 0 0' }}
                        >
                          <EditIcon size="medium" />
                        </IconButton> */}
                        <IconButton
                          variant="outlined"
                          style={{ color: "black" }}
                          size="medium"
                          onClick={() => {
                            self.handleDeleteTicket(row.ticketID);
                          }}
                        >
                          <DeleteIcon size="medium" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
          <div className="Complaints-MainSubContainer-Footer">
            <Pagination
              count={this.state.TotalPage}
              Page={this.state.PageNumber}
              onChange={this.handlePaging}
              variant="outlined"
              shape="rounded"
              color="secondary"
            />
          </div>
        </div>

        <Modal
          open={this.state.OpenTicket}
          onClose={this.handleClose}
          closeAfterTransition
          BackdropComponent={Backdrop}
          BackdropProps={{
            timeout: 500,
          }}
          className="Complaints-Model-Create-Ticket"
        >
          <Fade in={this.state.OpenTicket}>
            <div className="Complaints-Model-Create-Ticket-Main">
              <div className="Complaints-Model-Create-Ticket-Header">
                <div className="Complaints-Model-Create-Ticket-Header-Text">
                  Edit Ticket
                </div>
              </div>
              <div className="Complaints-Model-Create-Ticket-Body">
                <InputLabel required>Plan Type</InputLabel>
                <FormControl
                  variant="filled"
                  className="Complaints-Model-Create-Ticket-Body-PlanType"
                  size="small"
                  name="PlanType"
                  style={{ margin: "5px 0 20px 0" }}
                >
                  <Select
                    native
                    name="PlanType"
                    value={state.PlanType}
                    onChange={this.handleChanges}
                  >
                    <option value="device">Device</option>
                    <option value="plan">Plans</option>
                    <option value="other">Other</option>
                  </Select>
                </FormControl>
                <InputLabel required>Raise Type</InputLabel>
                <FormControl
                  variant="filled"
                  size="small"
                  name="RaiseType"
                  className="Complaints-Model-Create-Ticket-Body-IssueType"
                  style={{ margin: "5px 0 20px 0" }}
                >
                  <Select
                    native
                    name="RaiseType"
                    value={state.RaiseType}
                    onChange={this.handleChanges}
                  >
                    <option value="issue">Issue</option>
                    <option value="improvement">Improvement</option>
                    <option value="changerequest">Change Request</option>
                  </Select>
                </FormControl>
                <div className="Complaints-Line"></div>
                <InputLabel required>Summary</InputLabel>
                <TextField
                  variant="outlined"
                  size="small"
                  name="Summary"
                  className="Complaints-Model-Create-Ticket-Body-Summary"
                  style={{ margin: "5px 0 20px 0" }}
                  error={state.SummaryFlag}
                  value={state.Summary}
                  onChange={this.handleChanges}
                />
                <InputLabel required>Description</InputLabel>
                <TextField
                  variant="outlined"
                  size="small"
                  name="Description"
                  className="Complaints-Model-Create-Ticket-Body-Summary"
                  style={{ margin: "5px 0 20px 0" }}
                  multiline
                  rows={5}
                  error={state.DescriptionFlag}
                  value={state.Description}
                  onChange={this.handleChanges}
                />
                <InputLabel required>Reporter</InputLabel>
                <TextField
                  variant="outlined"
                  size="small"
                  name="Summary"
                  className="Complaints-Model-Create-Ticket-Body-Reportor"
                  style={{ margin: "5px 0 20px 0" }}
                  error={state.SummaryFlag}
                  value={state.Reportor}
                  // onChange={this.handleChanges}
                />
                <InputLabel required>Assigner</InputLabel>
                <FormControl
                  variant="outlined"
                  size="small"
                  name="RaiseType"
                  className="Complaints-Model-Create-Ticket-Body-Assigner"
                  style={{ margin: "5px 0 20px 0" }}
                >
                  <Select
                    native
                    name="Assigner"
                    // error={state.AssignerFlag}
                    value={state.Assigner}
                    onChange={this.handleChanges}
                  >
                    <option>None</option>
                    {Array.isArray(this.state.TechnicianData) &&
                    this.state.TechnicianData.length > 0 ? (
                      this.state.TechnicianData.map((data, index) => {
                        return (
                          <option value={data.technicianName} key={index}>
                            {data.technicianName}
                          </option>
                        );
                      })
                    ) : (
                      <option>Technicial Not Available</option>
                    )}
                  </Select>
                </FormControl>

                <InputLabel required>Status</InputLabel>
                <FormControl
                  variant="outlined"
                  size="small"
                  name="RaiseType"
                  className="Complaints-Model-Create-Ticket-Body-Assigner"
                  style={{ margin: "5px 0 20px 0" }}
                >
                  <Select
                    native
                    name="Status"
                    value={state.Status}
                    onChange={this.handleChanges}
                  >
                    {Array.isArray(this.state.StatusList) &&
                    this.state.StatusList.length > 0 ? (
                      this.state.StatusList.map((data, index) => {
                        return (
                          <option value={data} key={index}>
                            {data}
                          </option>
                        );
                      })
                    ) : (
                      <option>Something went wrong</option>
                    )}
                  </Select>
                </FormControl>
              </div>
              <div className="Complaints-Model-Create-Ticket-Footer">
                <Button
                  variant="contained"
                  style={{ margin: "10px" }}
                  onClick={() => {
                    this.handleClose();
                  }}
                >
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => {
                    this.handleUpdateTicket();
                  }}
                >
                  Update
                </Button>
              </div>
            </div>
          </Fade>
        </Modal>

        <Backdrop
          style={{ zIndex: "1", color: "#fff" }}
          open={this.state.OpenLoader}
          onClick={() => {
            this.setState({ OpenLoader: false });
          }}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
        <Snackbar
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
          open={state.OpenSnackBar}
          autoHideDuration={2000}
          onClose={this.handleSnackBarClose}
          message={state.Message}
          action={
            <React.Fragment>
              <Button
                color="secondary"
                size="small"
                onClick={this.handleSnackBarClose}
              >
                UNDO
              </Button>
              <IconButton
                size="small"
                aria-label="close"
                color="inherit"
                onClick={this.handleSnackBarClose}
              >
                <CloseIcon fontSize="small" />
              </IconButton>
            </React.Fragment>
          }
        />
      </div>
    );
  }
}
