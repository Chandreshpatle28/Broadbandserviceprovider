import React, { Component } from "react";
import "./History.scss";
import { TechnicianDataServices } from "../../services/TechnicianDataServices";

import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Pagination from "@material-ui/lab/Pagination";
import IconButton from "@material-ui/core/IconButton";
import EditIcon from "@material-ui/icons/Edit";
import DeleteIcon from "@material-ui/icons/Delete";
import Modal from "@material-ui/core/Modal";
import Backdrop from "@material-ui/core/Backdrop";
import Fade from "@material-ui/core/Fade";
import InputLabel from "@material-ui/core/InputLabel";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";

export default class History extends Component {
  constructor() {
    super();
    this.state = {
      rows: [],
      //
      PageNumber: 1,
      TotalPage: 0,
      //
      TicketID: "",
      InsertionDate: "",
      UserID: 0,
      Summary: "",
      PlanType: "",
      RaiseType: "",
      Assigner: "",
      Reportor: "",
      Status: "",
      Description: "",
      //
      OpenTicket: false,
    };
  }
  componentWillMount() {
    console.log("Complaints component will mount calling ... ");
    this.GetTickets(this.state.PageNumber);
  }

  GetTickets = (CurrentPageNumber) => {
    let data = {
      technicianName: localStorage.getItem("TechnicianFullName"),
      type: "done",
      pageNumber: CurrentPageNumber,
      numberOfRecordPerPage: 10,
    };
    TechnicianDataServices.GetTickets(data)
      .then((data) => {
        console.log("GetTickets Data : ", data);
        this.setState({
          rows: data.data,
          TotalPage: data.totalPage,
        });
      })
      .catch((error) => {
        console.log("GetTickets Error : ", error);
      });
  };

  OpenTicketModel = (data) => {
    this.setState({
      OpenTicket: true,
      TicketID: data.ticketID,
      InsertionDate: data.insertionDate,
      UserID: data.userID,
      Summary: data.summary,
      PlanType: data.planType,
      Assigner: data.assigner,
      Reportor: data.reportor,
      Status: data.status,
      Description: data.description,
    });
  };

  render() {
    let state = this.state;
    let self = this;
    return (
      <div className="History-MainContainer">
        <div className="History-MainSubContainer">
          <div className="History-MainSubContainer-Header">History</div>
          <div className="History-MainSubContainer-Body">
            <TableContainer component={Paper}>
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow style={{ display: "flex" }}>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 0.2,
                      }}
                      align="left"
                    >
                      Id
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 5,
                      }}
                      align="left"
                    >
                      Summary
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 1.2,
                      }}
                      align="left"
                    >
                      Product Type
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 1,
                      }}
                      align="left"
                    >
                      Assigner&nbsp;
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 1,
                      }}
                      align="left"
                    >
                      Reporter&nbsp;
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 1,
                      }}
                      align="left"
                    >
                      Status&nbsp;
                    </TableCell>
                    <TableCell
                      style={{
                        fontSize: 16,
                        flex: 1,
                      }}
                      align="left"
                    >
                      Operation
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {Array.isArray(state.rows) && state.rows.length > 0
                    ? state.rows.map((row) => (
                        <TableRow key={row.name} style={{ display: "flex" }}>
                          <TableCell
                            align="left"
                            component="th"
                            scope="row"
                            style={{ flex: 0.2 }}
                            onClick={() => {
                              this.OpenTicketModel(row);
                            }}
                          >
                            {row.ticketID}
                          </TableCell>
                          <TableCell
                            align="left"
                            style={{ flex: 4.7 }}
                            onClick={() => {
                              this.OpenTicketModel(row);
                            }}
                          >
                            {row.summary}
                          </TableCell>
                          <TableCell
                            align="left"
                            style={{ flex: 1.1 }}
                            onClick={() => {
                              this.OpenTicketModel(row);
                            }}
                          >
                            {row.planType}
                          </TableCell>
                          <TableCell
                            align="left"
                            style={{ flex: 0.9 }}
                            onClick={() => {
                              this.OpenTicketModel(row);
                            }}
                          >
                            {row.assigner}
                          </TableCell>
                          <TableCell
                            align="left"
                            style={{ flex: 1 }}
                            onClick={() => {
                              this.OpenTicketModel(row);
                            }}
                          >
                            {row.reportor}
                          </TableCell>
                          <TableCell
                            align="left"
                            style={{ flex: 1 }}
                            onClick={() => {
                              this.OpenTicketModel(row);
                            }}
                          >
                            {row.status}
                          </TableCell>
                          <TableCell
                            align="left"
                            style={{
                              flex: 1.2,
                              padding: 0,
                            }}
                          >
                            <IconButton
                              variant="outlined"
                              color="primary"
                              size="medium"
                              onClick={() => {
                                self.handleEditTicket(row);
                              }}
                              // style={{ margin: '0 px 0 0' }}
                            >
                              <EditIcon size="medium" />
                            </IconButton>
                            <IconButton
                              variant="outlined"
                              style={{ color: "black" }}
                              size="medium"
                              onClick={() => {
                                self.handleDeleteTicket(row.ticketID);
                              }}
                            >
                              <DeleteIcon size="medium" />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      ))
                    : null}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
          <div className="History-MainSubContainer-Footer">
            <Pagination
              count={this.state.TotalPage}
              Page={this.state.PageNumber}
              onChange={this.handlePaging}
              variant="outlined"
              shape="rounded"
              color="secondary"
            />
          </div>
        </div>

        <Modal
          open={this.state.OpenTicket}
          onClose={this.handleClose}
          closeAfterTransition
          BackdropComponent={Backdrop}
          BackdropProps={{
            timeout: 500,
          }}
          className="Complaints-Model-Create-Ticket"
        >
          <Fade in={this.state.OpenTicket}>
            <div className="Complaints-Model-Create-Ticket-Main">
              <div className="Complaints-Model-Create-Ticket-Header">
                <div className="Complaints-Model-Create-Ticket-Header-Text">
                  Edit Ticket
                </div>
              </div>
              <div className="Complaints-Model-Create-Ticket-Body">
                <InputLabel required>Plan Type</InputLabel>
                <FormControl
                  variant="filled"
                  className="Complaints-Model-Create-Ticket-Body-PlanType"
                  size="small"
                  name="PlanType"
                  style={{ margin: "5px 0 20px 0" }}
                >
                  <Select
                    native
                    name="PlanType"
                    value={state.PlanType}
                    onChange={this.handleChanges}
                  >
                    <option value="device">Device</option>
                    <option value="plan">Plans</option>
                    <option value="other">Other</option>
                  </Select>
                </FormControl>
                <InputLabel required>Raise Type</InputLabel>
                <FormControl
                  variant="filled"
                  size="small"
                  name="RaiseType"
                  className="Complaints-Model-Create-Ticket-Body-IssueType"
                  style={{ margin: "5px 0 20px 0" }}
                >
                  <Select
                    native
                    name="RaiseType"
                    value={state.RaiseType}
                    onChange={this.handleChanges}
                  >
                    <option value="issue">Issue</option>
                    <option value="improvement">Improvement</option>
                    <option value="changerequest">Change Request</option>
                  </Select>
                </FormControl>
                <div className="Complaints-Line"></div>
                <InputLabel required>Summary</InputLabel>
                <TextField
                  variant="outlined"
                  size="small"
                  name="Summary"
                  className="Complaints-Model-Create-Ticket-Body-Summary"
                  style={{ margin: "5px 0 20px 0" }}
                  error={state.SummaryFlag}
                  value={state.Summary}
                  onChange={this.handleChanges}
                />
                <InputLabel required>Description</InputLabel>
                <TextField
                  variant="outlined"
                  size="small"
                  name="Description"
                  className="Complaints-Model-Create-Ticket-Body-Summary"
                  style={{ margin: "5px 0 20px 0" }}
                  multiline
                  rows={5}
                  error={state.DescriptionFlag}
                  value={state.Description}
                  onChange={this.handleChanges}
                />
                <InputLabel required>Reporter</InputLabel>
                <TextField
                  variant="outlined"
                  size="small"
                  name="Summary"
                  className="Complaints-Model-Create-Ticket-Body-Reportor"
                  style={{ margin: "5px 0 20px 0" }}
                  error={state.SummaryFlag}
                  value={state.Reportor}
                  // onChange={this.handleChanges}
                />
                <InputLabel required>Assigner</InputLabel>
                <TextField
                  variant="outlined"
                  size="small"
                  name="Summary"
                  className="Complaints-Model-Create-Ticket-Body-Assigner"
                  style={{ margin: "5px 0 20px 0" }}
                  error={state.SummaryFlag}
                  value={state.Assigner}
                  onChange={this.handleChanges}
                />
              </div>
              <div className="Complaints-Model-Create-Ticket-Footer">
                <Button
                  variant="contained"
                  style={{ margin: "10px" }}
                  onClick={() => {
                    this.handleClose();
                  }}
                >
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => {
                    this.handleCreateTicket();
                  }}
                >
                  Create
                </Button>
              </div>
            </div>
          </Fade>
        </Modal>
      </div>
    );
  }
}
